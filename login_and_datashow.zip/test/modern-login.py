# -*- coding: utf-8 -*-
import pymysql
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QMainWindow, QHeaderView, QMessageBox
from pyqt5_plugins.examplebuttonplugin import QtGui
import sys

from untitled_ui import Ui_MainWindow
from login_ui import Ui_LoginMainWindow
from device_ui import Ui_device_select
import icons_rc  # pylint: disable=unused-import
from customized import PasswordEdit



# TODO: Improve readability


class LoginForm(QtWidgets.QWidget):
    """Basic login form.
    """
    def __init__(self, *args, **kwargs):
        super(LoginForm,self).__init__(*args, **kwargs)
        self.setup_ui()
        self.init()

        # 添加鼠标事件
        self.dragging = False  # 标记是否正在拖动
        self.offset = None  # 偏移量

    def mousePressEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = True
            self.offset = event.pos()

    def mouseMoveEvent(self, event: QtGui.QMouseEvent) -> None:
        if self.dragging:
            self.move(self.pos() + (event.pos() - self.offset))

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = False
            self.offset = None

    def setup_ui(self):
        """Setup the login form.
        """
        self.resize(320, 480)
        # remove the title bar
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        self.setStyleSheet(
            """
            QPushButton {
                border-style: outset;
                border-radius: 0px;
                padding: 6px;
            }
            QPushButton:hover {
                background-color: #cf7500;
                border-style: inset;
            }
            QPushButton:pressed {
                background-color: #ffa126;
                border-style: inset;
            }
            """
        )

        self.verticalLayout = QtWidgets.QVBoxLayout(self)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)

        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()

        self.widget = QtWidgets.QWidget(self)
        self.widget.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.widget.setStyleSheet(".QWidget{background-color: rgb(20, 20, 40);}")

        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout_2.setContentsMargins(9, 0, 0, 0)

        self.cancelButton = QtWidgets.QPushButton(self.widget)
        self.cancelButton.setMinimumSize(QtCore.QSize(35, 25))
        self.cancelButton.setMaximumSize(QtCore.QSize(35, 25))
        self.cancelButton.setStyleSheet("color: white;\n"
                                        "font: 13pt \"Verdana\";\n"
                                        "border-radius: 1px;\n"
                                        "opacity: 200;\n")
        self.cancelButton.clicked.connect(self.close)
        self.verticalLayout_2.addWidget(self.cancelButton, 0, QtCore.Qt.AlignRight)

        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setContentsMargins(-1, 15, -1, -1)

        self.label = QtWidgets.QLabel(self.widget)
        self.label.setMinimumSize(QtCore.QSize(100, 150))
        self.label.setMaximumSize(QtCore.QSize(150, 150))
        self.label.setStyleSheet("image: url(:/icons/icons/rocket_48x48.png);")
        self.verticalLayout_3.addWidget(self.label, 0, QtCore.Qt.AlignHCenter)

        self.formLayout_2 = QtWidgets.QFormLayout()
        self.formLayout_2.setContentsMargins(50, 35, 59, -1)

        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setStyleSheet("color: rgb(231, 231, 231);\n"
                                   "font: 15pt \"Verdana\";")
        self.formLayout_2.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.label_2)

        # self.lineEdit = QtWidgets.QLineEdit(self.widget)
        # self.lineEdit.setMinimumSize(QtCore.QSize(0, 40))
        # self.lineEdit.setStyleSheet("QLineEdit {\n"
        #                             "color: rgb(231, 231, 231);\n"
        #                             "font: 15pt \"Verdana\";\n"
        #                             "border: None;\n"
        #                             "border-bottom-color: white;\n"
        #                             "border-radius: 10px;\n"
        #                             "padding: 0 8px;\n"
        #                             "background: rgb(20, 20, 40);\n"
        #                             "selection-background-color: darkgray;\n"
        #                             "}")
        # self.lineEdit.setFocus(True)
        # self.formLayout_2.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.lineEdit)

        self.label_3 = QtWidgets.QLabel(self.widget)
        self.formLayout_2.setWidget(3, QtWidgets.QFormLayout.LabelRole, self.label_3)

        self.userlineEdit = QtWidgets.QLineEdit(self.widget)
        self.userlineEdit.setMinimumSize(QtCore.QSize(0, 40))
        self.userlineEdit.setStyleSheet("QLineEdit {\n"
                                      "color: rgb(231, 231, 231);\n"
                                      "font: 15pt \"Verdana\";\n"
                                      "border: None;\n"
                                      "border-bottom-color: white;\n"
                                      "border-radius: 10px;\n"
                                      "padding: 0 8px;\n"
                                      "background: rgb(20, 20, 40);\n"
                                      "selection-background-color: darkgray;\n"
                                      "}")
        self.formLayout_2.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.userlineEdit) #有4改成0

        self.pwdlineEdit = PasswordEdit(self.widget)
        self.pwdlineEdit.setMinimumSize(QtCore.QSize(0, 40))
        self.pwdlineEdit.setStyleSheet("QLineEdit {\n"
                                      "color: orange;\n"
                                      "font: 15pt \"Verdana\";\n"
                                      "border: None;\n"
                                      "border-bottom-color: white;\n"
                                      "border-radius: 10px;\n"
                                      "padding: 0 8px;\n"
                                      "background: rgb(20, 20, 40);\n"
                                      "selection-background-color: darkgray;\n"
                                      "}")
        self.formLayout_2.setWidget(3, QtWidgets.QFormLayout.FieldRole, self.pwdlineEdit)
        self.pwdlineEdit.setEchoMode(QtWidgets.QLineEdit.Password)

        self.line = QtWidgets.QFrame(self.widget)
        self.line.setStyleSheet("border: 2px solid white;")
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.formLayout_2.setWidget(2, QtWidgets.QFormLayout.SpanningRole, self.line)

        self.line_2 = QtWidgets.QFrame(self.widget)
        self.line_2.setStyleSheet("border: 2px solid orange;")
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.formLayout_2.setWidget(4, QtWidgets.QFormLayout.SpanningRole, self.line_2)

        self.signButton = QtWidgets.QPushButton(self.widget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.signButton.sizePolicy().hasHeightForWidth())

        self.signButton.setSizePolicy(sizePolicy)
        self.signButton.setMinimumSize(QtCore.QSize(0, 60))
        self.signButton.setAutoFillBackground(False)
        self.signButton.setStyleSheet("color: rgb(231, 231, 231);\n"
                                      "font: 17pt \"Verdana\";\n"
                                      "border: 2px solid orange;\n"
                                      "padding: 5px;\n"
                                      "border-radius: 3px;\n"
                                      "opacity: 200;\n"
                                      "")
        self.signButton.setAutoDefault(True)
        self.formLayout_2.setWidget(6, QtWidgets.QFormLayout.SpanningRole, self.signButton)

        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.formLayout_2.setItem(6, QtWidgets.QFormLayout.SpanningRole, spacerItem)
        self.verticalLayout_3.addLayout(self.formLayout_2)

        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem1)
        self.verticalLayout_2.addLayout(self.verticalLayout_3)

        self.horizontalLayout_3.addWidget(self.widget)
        self.horizontalLayout_3.setStretch(0, 1)
        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Form", "Form"))
        self.cancelButton.setText(_translate("Form", "X"))
        self.label_2.setText(_translate(
            "Form",
            "<html><head/><body><p><img src=\":/icons/icons/user_32x32.png\"/></p></body></html>"))
        self.label_3.setText(_translate(
            "Form",
            "<html><head/><body><p><img src=\":/icons/icons/lock_or_32x32.png\"/></p></body></html>"))

        self.signButton.setText(_translate("Form", "Sign In"))

    def init(self):
        self.signButton.clicked.connect(self.sign_button)

    def sign_button(self):
        print(self.userlineEdit.text())
        print(self.pwdlineEdit.text())
        print(self.userlineEdit.text() == "1111")
        print(self.pwdlineEdit.text() == "0000")
        if (str(self.pwdlineEdit.text()) == "0000" and str(self.userlineEdit.text()) == "1111"):
            dewin.show()
            # 2关闭本窗口
            self.close()

        else:
            QMessageBox.critical(self, '错误', '用户名或密码错误！')
            self.pwdlineEdit.clear()
            self.userlineEdit.clear()
            # return None

class device_window(QtWidgets.QMainWindow, Ui_device_select):
    def __init__(self):
        super(device_window, self).__init__()
        self.setupUi(self)  # 创建窗体对象
        self.device1.clicked.connect(self.device1_botton)  # 连接槽
        self.device2.clicked.connect(self.device2_botton)  # 连接槽

    def device1_botton(self): # 选设备1
        mainwin.show()
        # 2关闭本窗口
        self.close()

    def device2_botton(self):# 选设备2
        QMessageBox.critical(self, '设备', '所选设备2')
            # 2关闭本窗口
            # self.close()

class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MyMainWindow, self).__init__()
        self.setupUi(self)
        # 【读取】功能
        # self.pushButton.clicked.connect(self.update_data)

        # 显示时间  添加1个 状态栏
        self.statusbar = QtWidgets.QStatusBar(self)
        self.statusbar.setObjectName('statusbar')
        self.setStatusBar(self.statusbar)

        # 创建1个 QTimer计时器对象
        timer = QtCore.QTimer(self)

        # 发射timeout信号，与自定义槽函数关联
        timer.timeout.connect(self.showtime)

        # 定期1s检查新数据
        timer.timeout.connect(self.update_data)
        timer.start(1000)

        self.update_data() # 在列表的最后一行更新数据

        # 启动计时器
        timer.start()

    # 自定义槽函数，用来在状态栏中显示当前日期时间
    def showtime(self):
        # 获取当前日期时间
        datetime = QtCore.QDateTime.currentDateTime()
        # 格式化日期时间
        # weekday = datetime.toString(Qt.DayOfWeek)
        # print(weekday,"-----")
        text = datetime.toString("yyyy-MM-dd hh:mm:ss dddd")
        # 在状态栏中显示日期时间
        self.statusbar.showMessage(text)
        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)

    # 【读取】按钮功能
    def update_data(self):
        # 数据库连接对象
        conn = pymysql.connect(host='localhost', port=3306, user='root', password="123456", db="college")
        # 游标对象
        cur = conn.cursor()

        # 查询的sql语句
        sql = "SELECT * FROM score"
        cur.execute(sql)
        # 获取查询到的数据, 是以二维元组的形式存储的, 所以读取需要使用 data[i][j] 下标定位
        data = cur.fetchall()
        # 打印测试
        # print(data)
        # print(data[0][1]) # 打印第1行第2个数据, 也就是小明

        # 遍历二维元组, 将 id 和 name 显示到界面表格上
        x = 0
        for i in data:
            y = 0
            for j in i:
                self.tableWidget.setItem(x, y, QtWidgets.QTableWidgetItem(str(data[x][y])))
                y = y + 1
            x = x + 1

        cur.close()
        conn.close()

    def show_time(self):
        # 获取当前时间并设置为QTimeEdit的值
        current_datetime = QDateTime.currentDateTime()
        self.dateTimeEdit.setDateTime(current_datetime)

if __name__ == "__main__":
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    app = QtWidgets.QApplication(sys.argv)
    login_form = LoginForm()

    # lgwin = login_window()
    dewin = device_window()
    mainwin = MyMainWindow()

    login_form.show()

    sys.exit(app.exec_())
