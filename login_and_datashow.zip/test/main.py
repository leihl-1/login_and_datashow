import sys
from PyQt5 import QtCore,QtGui,QtWidgets
import pymysql
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QMainWindow, QHeaderView, QMessageBox
from untitled_ui import Ui_MainWindow
from login_ui import Ui_LoginMainWindow
from device_ui import Ui_device_select

class login_window(QtWidgets.QMainWindow, Ui_LoginMainWindow):
    def __init__(self):
        super(login_window, self).__init__()
        self.setupUi(self)  # 创建窗体对象
        self.init()
        self.admin = "111"
        self.Password = "000"

    def init(self):
        self.loginbotton.clicked.connect(self.login_button)  # 连接槽

    def login_button(self):

        if (self.pwdlineEdit_2.text() == self.Password) and self.userlineEdit.text() == self.admin:
            dewin.show()
            # 2关闭本窗口
            self.close()

        else:
            QMessageBox.critical(self, '错误', '用户名或密码错误！')
            self.pwdlineEdit_2.clear()
            self.userlineEdit.clear()
            return None

class device_window(QtWidgets.QMainWindow, Ui_device_select):
    def __init__(self):
        super(device_window, self).__init__()
        self.setupUi(self)  # 创建窗体对象
        self.device1.clicked.connect(self.device1_botton)  # 连接槽
        self.device2.clicked.connect(self.device2_botton)  # 连接槽

    def device1_botton(self): # 选设备1
        mainwin.show()
        # 2关闭本窗口
        self.close()

    def device2_botton(self):# 选设备2
        QMessageBox.critical(self, '设备', '所选设备2')
            # 2关闭本窗口
            # self.close()

class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MyMainWindow, self).__init__()
        self.setupUi(self)
        # 【读取】功能
        # self.pushButton.clicked.connect(self.update_data)

        # 显示时间  添加1个 状态栏
        self.statusbar = QtWidgets.QStatusBar(self)
        self.statusbar.setObjectName('statusbar')
        self.setStatusBar(self.statusbar)

        # 创建1个 QTimer计时器对象
        timer = QtCore.QTimer(self)

        # 发射timeout信号，与自定义槽函数关联
        timer.timeout.connect(self.showtime)

        # 定期1s检查新数据
        timer.timeout.connect(self.update_data)
        timer.start(1000)

        self.update_data() # 在列表的最后一行更新数据

        # 启动计时器
        timer.start()

    # 自定义槽函数，用来在状态栏中显示当前日期时间
    def showtime(self):
        # 获取当前日期时间
        datetime = QtCore.QDateTime.currentDateTime()
        # 格式化日期时间
        # weekday = datetime.toString(Qt.DayOfWeek)
        # print(weekday,"-----")
        text = datetime.toString("yyyy-MM-dd hh:mm:ss dddd")
        # 在状态栏中显示日期时间
        self.statusbar.showMessage(text)
        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)

    # 【读取】按钮功能
    def update_data(self):
        # 数据库连接对象
        conn = pymysql.connect(host='localhost', port=3306, user='root', password="123456", db="college")
        # 游标对象
        cur = conn.cursor()

        # 查询的sql语句
        sql = "SELECT * FROM score"
        cur.execute(sql)
        # 获取查询到的数据, 是以二维元组的形式存储的, 所以读取需要使用 data[i][j] 下标定位
        data = cur.fetchall()
        # 打印测试
        # print(data)
        # print(data[0][1]) # 打印第1行第2个数据, 也就是小明

        # 遍历二维元组, 将 id 和 name 显示到界面表格上
        x = 0
        for i in data:
            y = 0
            for j in i:
                self.tableWidget.setItem(x, y, QtWidgets.QTableWidgetItem(str(data[x][y])))
                y = y + 1
            x = x + 1

        cur.close()
        conn.close()

    def show_time(self):
        # 获取当前时间并设置为QTimeEdit的值
        current_datetime = QDateTime.currentDateTime()
        self.dateTimeEdit.setDateTime(current_datetime)

if __name__=='__main__':
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)

    app=QtWidgets.QApplication(sys.argv)

    lgwin = login_window()
    dewin = device_window()
    mainwin = MyMainWindow()

    lgwin.show()

    sys.exit(app.exec_())

